INTERACTION CONTROLS

### Mouse/trackpad controls

1. Click + drag: orbit/rotate camera (look around)
2. Scroll/trackpad/wheel: zoom in/out
3. Single click: nudge camera toward clicked point

### Keyboard controls

1. W:
