// processes the user/client's actions, computes deltaXY which are then used by camera
export class Controls {
  constructor(renderer) {
    this.renderer = renderer;
    this.canvas = renderer.canvas;
    this.camera = renderer.camera;

    // NEW: global state for mouse dragging
    this.isDragging = false;
    this.prevMouseX = 0;
    this.prevMouseY = 0;
    this.dragged = false;

    // Environment
    this.ppmInput = document.getElementById("ppmInput");

    // Object Model
    this.objectRotateX = document.getElementById("objectRotateXSlider");
    this.objectRotateXOut = document.getElementById("objectRotateXVal");
    this.objectRotateY = document.getElementById("objectRotateYSlider");
    this.objectRotateYOut = document.getElementById("objectRotateYVal");
    this.objectRotateZ = document.getElementById("objectRotateZSlider");
    this.objectRotateZOut = document.getElementById("objectRotateZVal");
    this.objectScale = document.getElementById("objectScaleSlider");
    this.objectScaleOut = document.getElementById("objectScaleVal");

    // TODO: Read step_size variables
    this.walkStep = document.getElementById("walkStepSlider");
    this.walkStepOut = document.getElementById("walkStepVal");
    this.lookStep = document.getElementById("lookStepSlider");
    this.lookStepOut = document.getElementById("lookStepVal");

    // Object
    this.objectPlyInput = document.getElementById("plyInput");
    this.objectPPMInput = document.getElementById("objectPPMInput");
    this.blend = document.getElementById("textureBlend");
    this.blendOut = document.getElementById("textureBlendVal");
    this.diffuse = false;
    this.diffuseCheckBox = document.getElementById("diffuseCheckbox");

    // Shader
    this.reloadShadersBtn = document.getElementById("reloadShadersBtn");

    // file input
    this.update(); // initialize output values
    this.setupEventListeners(renderer);
  }

  setupEventListeners(renderer) {
    // Environment
    this.ppmInput?.addEventListener("change", (e) =>
      renderer.loadPPMFile(e, "environment")
    );

    // Object Model
    this.objectRotateX?.addEventListener("input", () =>
      this.getObjectTransform()
    );
    this.objectRotateY?.addEventListener("input", () =>
      this.getObjectTransform()
    );
    this.objectRotateZ?.addEventListener("input", () =>
      this.getObjectTransform()
    );
    this.objectScale?.addEventListener("input", () =>
      this.getObjectTransform()
    );

    // Object: load files
    this.objectPlyInput?.addEventListener("change", (e) =>
      renderer.loadPLYFile(e)
    );
    this.objectPPMInput?.addEventListener("change", (e) =>
      renderer.loadPPMFile(e, "object")
    );
    this.diffuseCheckBox?.addEventListener("change", (e) => {
      this.diffuse = e.target.checked;
    });

    // Shader
    this.reloadShadersBtn?.addEventListener("click", () => {
      renderer.reloadShaders("inner");
      renderer.reloadShaders("outer");
    });

    // labels
    ["input", "change"].forEach((evt) => {
      this.walkStep?.addEventListener(evt, this.update);
      this.lookStep?.addEventListener(evt, this.update);
      this.objectRotateX?.addEventListener(evt, this.update);
      this.objectRotateY?.addEventListener(evt, this.update);
      this.objectRotateZ?.addEventListener(evt, this.update);
      this.objectScale?.addEventListener(evt, this.update);
      this.blend?.addEventListener(evt, this.update);
    });

    // TODO: add event listeners for mouse/trackpad controls
    if (this.canvas) {
      this.canvas.addEventListener('mousedown', (event) => {
        this.onMouseDown(event)
      });
      this.canvas.addEventListener('mousemove', (event) => {
        this.onMouseMove(event)
      });
      this.canvas.addEventListener('mouseup', (event) => {
        this.onMouseUp(event)
      });
      this.canvas.addEventListener('mouseleave', (event) => {
        this.onMouseUp(event)
      });
      this.canvas.addEventListener('mousewheel', (event) => {
        this.onWheel(event)
      });
    }

    // TODO: listen for keyboard controls (WASD + arrows)
    window.addEventListener('keydown', (event) => {
      const MOVE_STEP = this.getWalkStep();
      const LOOK_STEP = this.getLookStep();
      console.log(event.key);
      if (event.key === 'ArrowDown') {
        this.camera.rotate(0, LOOK_STEP);
      } 
      if (event.key === 'ArrowUp') {
        this.camera.rotate(0, -LOOK_STEP);
      } 
      if (event.key === 'ArrowLeft') {
        this.camera.rotate(-LOOK_STEP, 0);
      } 
      if (event.key === 'ArrowRight') {
        this.camera.rotate(LOOK_STEP, 0);
      } 
      if (event.key === 'w') {
        this.camera.moveForward(MOVE_STEP);
      } 
      if (event.key === 'a') {
        this.camera.moveRight(-MOVE_STEP);
      } 
      if (event.key === 's') {
        this.camera.moveForward(-MOVE_STEP);
      } 
      if (event.key === 'd') {
        this.camera.moveRight(MOVE_STEP);
      } 
    });
   
  }

  // update slider outputs
  update = () => {
    if (this.blend && this.blendOut) {
      this.blendOut.textContent = this.blend.value;
    }
    if (this.objectRotateX && this.objectRotateXOut) {
      this.objectRotateXOut.textContent = this.objectRotateX.value;
    }
    if (this.objectRotateY && this.objectRotateYOut) {
      this.objectRotateYOut.textContent = this.objectRotateY.value;
    }
    if (this.objectRotateZ && this.objectRotateZOut) {
      this.objectRotateZOut.textContent = this.objectRotateZ.value;
    }
    if (this.objectScale && this.objectScaleOut) {
      this.objectScaleOut.textContent = this.objectScale.value;
    }
    if (this.walkStep && this.walkStepOut) {
      this.walkStepOut.textContent = this.walkStepOut.value;
    }
    if (this.lookStep && this.lookStepOut) {
      this.lookStepOut.textContent = this.lookStepOut.value;
    }
  };

  // TODO: helper functions to parse float for walkStep and lookStep from html
  getWalkStep() {
    return parseFloat(this.walkStep.value)
  }
  getLookStep() {
    return parseFloat(this.lookStep.value)
  }

  // parse float
  getObjectTransform() {
    if (!this.renderer?.objectTransform) return;
    this.renderer.objectTransform.rotateX = parseFloat(
      this.objectRotateX.value
    );
    this.renderer.objectTransform.rotateY = parseFloat(
      this.objectRotateY.value
    );
    this.renderer.objectTransform.rotateZ = parseFloat(
      this.objectRotateZ.value
    );
    this.renderer.objectTransform.scale = parseFloat(this.objectScale.value);
  }

  // ===================== Drag, Wheel, Pan =====================
  // TODO: handle mouse events
  onMouseDown(event) {
    // TODO: set variables: this.isDragging, this.prevMouseX, this.prevMouseY, this.dragged
    this.isDragging = true;
    this.prevMouseX = event.clientX;
    this.prevMouseY = event.clientY;
    this.dragged = false;
  }

  onMouseMove(event) {
    if (!this.isDragging) return; // error check: don't do anything if not in dragging mode

    // TODO: compute delta X and Y in pixel space (mouse movement)
    const deltaX = event.clientX - this.prevMouseX ;
    const deltaY = event.clientY - this.prevMouseY ;
  
    // TODO: orbit camera using Camera.rotate (delta is in pixels)
    this.camera.rotate(deltaX, deltaY);

    const MOVE_THRESH = 3;
    if (Math.abs(deltaX) > MOVE_THRESH || Math.abs(deltaY > MOVE_THRESH)) {
      this.dragged = true;
    }
    
    // TODO: update prevMouseX and prevMouseY
    this.prevMouseX = event.clientX;
    this.prevMouseY = event.clientY;
  }

  onMouseUp() {
    this.isDragging = false;
    // TODO: set variables: this.isDragging
  }

  onWheel(event) {
    // TODO: handle trackpad / mouse wheel zoom; HINT: by calling camera's zoom function
    this.camera.adjustZoom(event.deltaY)
    event.preventDefault(); // avoid page scroll while zooming
  }

  // ----------------- Keyboard controls: WASD + arrow keys: -----------------
  onKeyDown(event) {
    // TODO: get variables MOVE_STEP and LOOK_STEP
    // const MOVE_STEP = ...
    // const LOOK_STEP = ...
    let handled = false;

    switch (event.code) {
      // ----- LOOKING: Arrow keys -----
      case "ArrowLeft":
        // TODO: adjust camera to look left
        handled = true;
        break;
      case "ArrowRight":
        // TODO: adjust camera to look right
        handled = true;
        break;
      case "ArrowUp":
        // TODO: adjust camera to look up
        handled = true;
        break;
      case "ArrowDown":
        // TODO: adjust camera to look down
        handled = true;
        break;

      // ----- WALKING: WASD -----
      // TODO: handle W, A, S, D cases by calling camera.moveForward() and camera.moveRight()
    }

    if (handled) {
      event.preventDefault(); // avoid scrolling the page with keys
    }
  }

  // ------------ OPTIONAL: Mouse controls: Single + Double Clicks -------------

  // onDoubleClick() {
  //   //small zoom-in (negative value = zoom in based on adjustZoom logic)
  // }

  // Google maps esque: click near an area → orient and then zoom toward it
  // onClick(event) {
  // }
}
