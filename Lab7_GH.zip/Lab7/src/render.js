import { PLYParser } from "./ply.js";
import { Camera } from "./camera.js";
import { ShaderProgram } from "./shaderProgram.js";
import { Controls } from "../controls.js";
import { Mesh } from "./mesh.js";
import { loadPPMFromText } from "./ppm.js";

export class WebGLRenderer {
  constructor(canvasId, statusId) {
    this.canvas = document.getElementById(canvasId); // make a canvas
    this.statusElem = document.getElementById(statusId); // tells user status, eg file loaded successfully
    this.gl = null; // webgl context
    this.camera = new Camera(); // our own camera class; handles transformations
    this.objectTransform = {
      rotateX: 0,
      rotateY: 0,
      rotateZ: 0,
      scale: 1,
    };
    this.controls = new Controls(this); // pass the entire renderer instance

    // two different objects with different shader programs
    this.programs = {}; // shader program manager
    this.innerMesh = new Mesh(); // the inner object
    this.outerMesh = new Mesh(); // the outer object
    this.textures = { environment: null, object: null };

    this.init();
  }

  async init() {
    if (!this.initGL()) return;
    await this.setupShaders();
    await this.loadOuter(); // load the outer sphere mesh
    this.startRenderLoop();
  }

  initGL() {
    this.gl = this.canvas.getContext("webgl");
    if (!this.gl) {
      this.statusElem.textContent =
        "Error: WebGL not supported in this browser.";
      return false;
    }
    this.gl.clearColor(0.1, 0.1, 0.1, 1.0); // background color is dark grey by default
    this.gl.enable(this.gl.DEPTH_TEST);
    return true;
  }

  async setupShaders() {
    try {
      await this.loadShaders("inner");
      await this.loadShaders("outer");
      this.statusElem.textContent = "Shaders loaded successfully!";
    } catch (error) {
      console.error("Shader setup failed:", error);
      this.statusElem.textContent =
        "Shader compilation failed: " + error.message;
    }
  }

  async loadShaders(name) {
    const vsText = await fetch(`./shaders/${name}.vert`).then((r) => r.text());
    const fsText = await fetch(`./shaders/${name}.frag`).then((r) => r.text());
    this.programs[name] = new ShaderProgram(this.gl, vsText, fsText);
  }

  async reloadShaders(name) {
    try {
      const vsText = await fetch(`./shaders/${name}.vert`).then((r) =>
        r.text()
      );
      const fsText = await fetch(`./shaders/${name}.frag`).then((r) =>
        r.text()
      );
      this.programs[name].reload(vsText, fsText);
      this.statusElem.textContent = "Shaders reloaded successfully!";
    } catch (error) {
      console.error("Shader reload failed:", error);
      this.statusElem.textContent = "Shader reload failed: " + error.message;
    }
  }

  /************** File Reading Helper Functions ***************/

  readFileAsText(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = () => reject(new Error("Failed to read file"));
      reader.readAsText(file);
    });
  }

  async loadPLYFile(event) {
    const file = event.target.files[0];
    if (!file) return;
    this.statusElem.textContent = "Loading PLY file...";
    try {
      const text = await this.readFileAsText(file);
      const plyData = PLYParser.parse(text);
      this.innerMesh.loadData(plyData.vertices, plyData.faces);
      this.innerMesh.processGeometry();
      this.innerMesh.createBuffers(this.gl);
      this.statusElem.textContent = `PLY "${file.name}" loaded successfully! (${
        plyData.vertices.length / 3
      } vertices, ${plyData.faces.length / 3} faces)`;
    } catch (error) {
      console.error(`PLY "${file.name}" loading failed:`, error);
      this.statusElem.textContent =
        `Error loading PLY "${file.name}": ` + error.message;
    }
  }

  async loadPPMFile(event, name) {
    const file = event.target.files[0];
    if (!file) return;
    this.statusElem.textContent = "Loading PPM file...";
    try {
      const text = await this.readFileAsText(file);
      const { tex, width, height } = loadPPMFromText(this.gl, text);

      this.textures[name] = tex;

      const textureUnit =
        {
          environment: this.gl.TEXTURE0,
          object: this.gl.TEXTURE1,
        }[name] || this.gl.TEXTURE0;

      this.gl.activeTexture(textureUnit);
      this.gl.bindTexture(this.gl.TEXTURE_2D, tex);

      this.statusElem.textContent = `PPM "${file.name}" loaded successfully! (${width} x ${height})`;
    } catch (error) {
      console.error(`PPM "${file.name}" loading failed:`, error);
      this.statusElem.textContent =
        `Error loading PPM "${file.name}": ` + error.message;
    }
  }

  resizeCanvasToDisplaySize() {
    const dpr = window.devicePixelRatio || 1;
    const displayWidth = Math.round(this.canvas.clientWidth * dpr);
    const displayHeight = Math.round(this.canvas.clientHeight * dpr);
    if (
      this.canvas.width !== displayWidth ||
      this.canvas.height !== displayHeight
    ) {
      this.canvas.width = displayWidth;
      this.canvas.height = displayHeight;
      this.gl.viewport(0, 0, displayWidth, displayHeight);
    }
  }

  startRenderLoop() {
    const renderLoop = () => {
      this.render();
      requestAnimationFrame(renderLoop);
    };
    renderLoop();
  }

  // outer sphere initialization
  async loadOuter() {
    const file = "./data/sphere.ply";
    const texFile = "./data/sphere-map-nature.ppm";
    try {
      const response = await fetch(file);
      const text = await response.text();
      const plyData = PLYParser.parse(text);
      this.outerMesh.loadData(plyData.vertices, plyData.faces);
      this.outerMesh.processGeometry();
      this.outerMesh.createBuffers(this.gl);
      console.log(
        `Outer mesh "${file}" loaded successfully! (${
          plyData.vertices.length / 3
        } vertices, ${plyData.faces.length / 3} faces)`
      );
      const texResponse = await fetch(texFile);
      const texText = await texResponse.text();
      const { tex, width, height } = loadPPMFromText(this.gl, texText);
      this.textures["environment"] = tex;
      console.log(
        `Texture "${texFile}" loaded successfully! (${width} x ${height})`
      );
    } catch (error) {
      console.error(`Outer mesh "${file}" loading failed:`, error);
    }
  }

  objectMatrix() {
    const modelWorld = mat4.create();
    // apply object transformations here
    mat4.rotateX(
      modelWorld,
      modelWorld,
      (this.objectTransform.rotateX / 180) * Math.PI
    );
    mat4.rotateY(
      modelWorld,
      modelWorld,
      (this.objectTransform.rotateY / 180) * Math.PI
    );
    mat4.rotateZ(
      modelWorld,
      modelWorld,
      (this.objectTransform.rotateZ / 180) * Math.PI
    );
    mat4.scale(modelWorld, modelWorld, [
      this.objectTransform.scale,
      this.objectTransform.scale,
      this.objectTransform.scale,
    ]);
    return modelWorld;
  }

  render() {
    this.resizeCanvasToDisplaySize(); // make sure canvas size is correct

    const gl = this.gl;
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    const matrices = this.camera.getMatrices(
      this.canvas.clientWidth / this.canvas.clientHeight
    ); // camera transformations
    if (this.outerMesh.isReady()) this.renderOuter(matrices);
    if (this.innerMesh.isReady()) this.renderInner(matrices);
  }

  renderInner(matrices) {
    const gl = this.gl;
    const program = this.programs.inner;
    program.use();

    const modelMatrix = this.objectMatrix();
    const viewMatrix = matrices.modelView;

    const normalMatrix = mat3.create();
    mat3.normalFromMat4(normalMatrix, modelMatrix);

    const viewInv = mat4.create();
    mat4.invert(viewInv, viewMatrix);
    const camPos = [viewInv[12], viewInv[13], viewInv[14]];

    // setting uniforms
    program.setMatrix4("u_modelMatrix", modelMatrix);
    program.setMatrix4("u_viewMatrix", viewMatrix);
    program.setMatrix4("u_projectionMatrix", matrices.projection);
    program.setMatrix3("u_normalMatrix", normalMatrix);
    program.setVector3("u_cameraPosWorld", camPos);
    program.setVector3("u_lightDirWorld", [0.0, 0.0, -1.0]);
    program.setFloat(
      "u_blend",
      this.controls.blend ? parseFloat(this.controls.blend.value) : 0.0
    );
    program.setInteger("u_diffuse", this.controls.diffuse ? 1 : 0);

    this.innerMesh.bindForFillRender(gl, program);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.textures["environment"]);
    program.setInteger("uTexture", 0);
    if (this.textures["object"]) {
      gl.activeTexture(gl.TEXTURE1);
      gl.bindTexture(gl.TEXTURE_2D, this.textures["object"]);
      program.setInteger("uObjectTexture", 1);
    } else {
      program.setInteger("uObjectTexture", 0);
    }
    gl.drawArrays(gl.TRIANGLES, 0, this.innerMesh.getVertexCount());
  }

  renderOuter(matrices) {
    const gl = this.gl;
    const program = this.programs.outer;
    program.use();
    program.setMatrix4("u_projectionMatrix", matrices.projection);
    program.setMatrix4("u_modelViewMatrix", matrices.modelView);
    this.outerMesh.bindForFillRender(gl, program);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.textures["environment"]);
    program.setInteger("uTexture", 0);
    gl.drawArrays(gl.TRIANGLES, 0, this.outerMesh.getVertexCount());
  }
}
