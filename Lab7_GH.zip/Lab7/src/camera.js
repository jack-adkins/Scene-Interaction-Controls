// lab 7 camera
export class Camera {
  constructor() {
    this.rotU = 0; // look up/down (X)
    this.rotV = 0; // look left/right (Y)
    this.position = [0, 0, 3.0]; // NEW: camera's pos in world space, to allow 'walking'

    // NEW: distance clamp (for zoom / walk)
    this.minDist = 0.8; // prevent going into the object
    this.maxDist = 3.75; // prevent going outside the environment
  }

  // ---------- matrices ----------
  getMatrices(aspectRatio) {
    const projection = mat4.create();
    mat4.perspective(projection, Math.PI / 4, aspectRatio, 0.1, 100.0);

    const modelView = mat4.create();
    // rotate camera (look around)
    mat4.rotateX(modelView, modelView, this.rotU);
    mat4.rotateY(modelView, modelView, this.rotV);
    // NEW: then move the world opposite of the camera position
    mat4.translate(modelView, modelView, [
      -this.position[0], // now a variable instead of always 0
      -this.position[1], // now a variable instead of always 0
      -this.position[2],
    ]);

    const normal = mat3.create();
    mat3.normalFromMat4(normal, modelView);

    return { projection, modelView, normal };
  }

  // ---------- rotation (look around) ----------
  rotate(deltaX, deltaY) {
    this.rotV += deltaX * 0.01; // 0.01 = sensitivity
    this.rotU += deltaY * 0.01;

    // OPTIONAL: clamp pitch so the camera doesn't flip
  }

  setRotate(rotateX, rotateY) {
    this.rotV = rotateX;
    this.rotU = rotateY;
  }

  // ---------- helpers for movement (walking) ----------
  // TODO: return the direction the camera is looking, as a unit vector in world space
  getForward() {
    const m = this.getMatrices().modelView
    console.log(m)
    return vec3.normalize(vec3.create(), vec4.transformMat4(vec4.create(), vec4.fromValues(0, 0, -1, 0), m))
  }

  // right vector (walk left/right)
  getRight() {
    const up = [0, 1, 0]; // World up direction is fixed as +Y
    const forward = this.getForward(); // TODO: update forward vector

    const right = vec3.cross(vec3.create(), forward, up); // TODO: right = forward x up

    // TODO: normalize right vector
    return vec3.normalize(right, right); // replace with normalized_right
  }

  // get distance from origin - “radius” from the origin, the center of the environment
  getDistance() {
    const [x, y, z] = this.position;
    return Math.hypot(x, y, z); // sqrt(x^2 + y^2 + z^2)
  }

  setDistance(newDist) {
    const d = this.getDistance();
    if (d === 0) return;
    const scale = newDist / d;
    this.position[0] *= scale;
    this.position[1] *= scale;
    this.position[2] *= scale;
  }

  // helper function to keep distance within min/max
  clampDistance() {
    const d = this.getDistance();
    const clamped = Math.max(this.minDist, Math.min(this.maxDist, d));
    if (clamped !== d) this.setDistance(clamped);
  }

  // ---------- NEW: walking movement, move camera ----------
  moveForward(amount) {
    const f = this.getForward();
    console.log(f);
    this.position[0] += f[0] * amount;
    this.position[1] += f[1] * amount;
    this.position[2] += f[2] * amount;

    this.clampDistance(); // call helper to keep within min/max distance
  }

  moveRight(amount) {
    const r = this.getRight();
    console.log(r);
    this.position[0] += r[0] * amount;
    this.position[1] += r[1] * amount;
    this.position[2] += r[2] * amount;

    this.clampDistance(); // call helper to keep within min/max distance
  }

  // ---------- zoom (wheel / double-click) ----------
  setZoom(newZoom) {
    const z = Math.max(this.minDist, Math.min(this.maxDist, newZoom));
    this.setDistance(z);
  }

  adjustZoom(deltaY) {
    const ZOOM_SENSITIVITY = 0.003;
    const dist = this.getDistance(); // current radius from origin
    const newDist = dist + deltaY * ZOOM_SENSITIVITY;
    this.setZoom(newDist); // clamps to [minDist, maxDist] and rescales position
  }
}
